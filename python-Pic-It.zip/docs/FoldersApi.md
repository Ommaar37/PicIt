# swagger_client.FoldersApi

All URIs are relative to *https://virtserver.swaggerhub.com/EPEREIROS_1/PicIt/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**v1_folder_get**](FoldersApi.md#v1_folder_get) | **GET** /v1/folder | 
[**v1_folder_id_get**](FoldersApi.md#v1_folder_id_get) | **GET** /v1/folder/{id} | 
[**v1_folders_id_patch**](FoldersApi.md#v1_folders_id_patch) | **PATCH** /v1/folders/{id} | 
[**v1_folders_post**](FoldersApi.md#v1_folders_post) | **POST** /v1/folders | 

# **v1_folder_get**
> v1_folder_get(object=object, name=name)



Mostrar las carpetas del usuario

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FoldersApi()
object = 56 # int | Id de la carpeta (optional)
name = 'name_example' # str | Nombre de la carpeta (optional)

try:
    api_instance.v1_folder_get(object=object, name=name)
except ApiException as e:
    print("Exception when calling FoldersApi->v1_folder_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **object** | **int**| Id de la carpeta | [optional] 
 **name** | **str**| Nombre de la carpeta | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v1_folder_id_get**
> v1_folder_id_get(object=object, object=object, object=object, object=object, object=object)



Mostrar las publicaciones de una carpeta

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FoldersApi()
object = 56 # int | Id de la publicación que está dentro de la carpeta (optional)
object = 'object_example' # str | Título de la publicación que está dentro de la carpeta (optional)
object = 'object_example' # str | Archivo de la imagen de la publicación que está dentro de la carpeta (optional)
object = '2013-10-20' # date | Fecha en la que se publicó la publicación que está dentro de la carpeta (optional)
object = 'object_example' # str | Tags de la publicación que está dentro de la carpeta (optional)

try:
    api_instance.v1_folder_id_get(object=object, object=object, object=object, object=object, object=object)
except ApiException as e:
    print("Exception when calling FoldersApi->v1_folder_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **object** | **int**| Id de la publicación que está dentro de la carpeta | [optional] 
 **object** | **str**| Título de la publicación que está dentro de la carpeta | [optional] 
 **object** | **str**| Archivo de la imagen de la publicación que está dentro de la carpeta | [optional] 
 **object** | [**date**](.md)| Fecha en la que se publicó la publicación que está dentro de la carpeta | [optional] 
 **object** | **str**| Tags de la publicación que está dentro de la carpeta | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v1_folders_id_patch**
> v1_folders_id_patch(object=object, object=object, object=object)



Añadir una publicación a una carpeta

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FoldersApi()
object = true # bool | Boolean que indica si se añade o no la publicación a la carpeta (optional)
object = 'object_example' # str | Path donde se almacena la carpeta con la publicación (optional)
object = 56 # int | Id de la publicación que se añade a la carpeta (optional)

try:
    api_instance.v1_folders_id_patch(object=object, object=object, object=object)
except ApiException as e:
    print("Exception when calling FoldersApi->v1_folders_id_patch: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **object** | **bool**| Boolean que indica si se añade o no la publicación a la carpeta | [optional] 
 **object** | **str**| Path donde se almacena la carpeta con la publicación | [optional] 
 **object** | **int**| Id de la publicación que se añade a la carpeta | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v1_folders_post**
> v1_folders_post(name=name)



Crear carpeta

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FoldersApi()
name = 'name_example' # str | Asignar nombre a la carpeta (optional)

try:
    api_instance.v1_folders_post(name=name)
except ApiException as e:
    print("Exception when calling FoldersApi->v1_folders_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **str**| Asignar nombre a la carpeta | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

