# swagger_client.PostsApi

All URIs are relative to *https://virtserver.swaggerhub.com/EPEREIROS_1/PicIt/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**posts_post**](PostsApi.md#posts_post) | **POST** /posts | 
[**v1_posts_id_get**](PostsApi.md#v1_posts_id_get) | **GET** /v1/posts/{id} | 
[**v1_posts_id_like_put**](PostsApi.md#v1_posts_id_like_put) | **PUT** /v1/posts/{id}/like | 
[**v1_postsquery_get**](PostsApi.md#v1_postsquery_get) | **GET** /v1/posts?query | 

# **posts_post**
> posts_post(object=object, object=object, object=object, object=object)



Subir post

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.PostsApi()
object = 'object_example' # str | Título del post (optional)
object = 'object_example' # str | Descripción de la publicación (optional)
object = 'object_example' # str | Archivo de imagen de la publicación (optional)
object = 56 # int | Ids de los tags de la publicación (optional)

try:
    api_instance.posts_post(object=object, object=object, object=object, object=object)
except ApiException as e:
    print("Exception when calling PostsApi->posts_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **object** | **str**| Título del post | [optional] 
 **object** | **str**| Descripción de la publicación | [optional] 
 **object** | **str**| Archivo de imagen de la publicación | [optional] 
 **object** | **int**| Ids de los tags de la publicación | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v1_posts_id_get**
> v1_posts_id_get(object=object, object=object, object=object, object=object, object=object, object=object)



Obtener detalle de la publicación

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.PostsApi()
object = 'object_example' # str | Id de publicación (optional)
object = 'object_example' # str | Título de publicación (optional)
object = 'object_example' # str | description (optional)
object = 'object_example' # str | Archivo de imagen publicado (optional)
object = '2013-10-20' # date | Fecha de publicación (optional)
object = 'object_example' # str | Tags de la publicación (optional)

try:
    api_instance.v1_posts_id_get(object=object, object=object, object=object, object=object, object=object, object=object)
except ApiException as e:
    print("Exception when calling PostsApi->v1_posts_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **object** | **str**| Id de publicación | [optional] 
 **object** | **str**| Título de publicación | [optional] 
 **object** | **str**| description | [optional] 
 **object** | **str**| Archivo de imagen publicado | [optional] 
 **object** | [**date**](.md)| Fecha de publicación | [optional] 
 **object** | **str**| Tags de la publicación | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v1_posts_id_like_put**
> v1_posts_id_like_put()



Guardar como favorita una publicación

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.PostsApi()

try:
    api_instance.v1_posts_id_like_put()
except ApiException as e:
    print("Exception when calling PostsApi->v1_posts_id_like_put: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v1_postsquery_get**
> v1_postsquery_get(object=object, object=object, object=object, object=object, object=object)



Recupera publicaciones para ver en la página de inicio; permite buscar

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.PostsApi()
object = 'object_example' # str | Id de publicación (optional)
object = 'object_example' # str | Título de publicación (optional)
object = 'object_example' # str | Archivo de imagen publicado (optional)
object = '2013-10-20' # date | Fecha de publicación (optional)
object = 'object_example' # str | Tags de la publicación (optional)

try:
    api_instance.v1_postsquery_get(object=object, object=object, object=object, object=object, object=object)
except ApiException as e:
    print("Exception when calling PostsApi->v1_postsquery_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **object** | **str**| Id de publicación | [optional] 
 **object** | **str**| Título de publicación | [optional] 
 **object** | **str**| Archivo de imagen publicado | [optional] 
 **object** | [**date**](.md)| Fecha de publicación | [optional] 
 **object** | **str**| Tags de la publicación | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

