# swagger_client.LikeApi

All URIs are relative to *https://virtserver.swaggerhub.com/EPEREIROS_1/PicIt/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**v1_liked_get**](LikeApi.md#v1_liked_get) | **GET** /v1/liked | 

# **v1_liked_get**
> v1_liked_get(object=object, object=object, object=object, object=object, object=object)



Muestra mis publicaciones likeadas

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.LikeApi()
object = 56 # int | Id del like (optional)
object = 'object_example' # str | Titulo de la publicación likeada (optional)
object = 'object_example' # str | Archivo de imagen de la publicación likeada (optional)
object = '2013-10-20' # date | Fecha en la que fue likeada la publicación (optional)
object = 'object_example' # str | Tags de la publicación likeada (optional)

try:
    api_instance.v1_liked_get(object=object, object=object, object=object, object=object, object=object)
except ApiException as e:
    print("Exception when calling LikeApi->v1_liked_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **object** | **int**| Id del like | [optional] 
 **object** | **str**| Titulo de la publicación likeada | [optional] 
 **object** | **str**| Archivo de imagen de la publicación likeada | [optional] 
 **object** | [**date**](.md)| Fecha en la que fue likeada la publicación | [optional] 
 **object** | **str**| Tags de la publicación likeada | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

