# swagger_client.UsersApi

All URIs are relative to *https://virtserver.swaggerhub.com/EPEREIROS_1/PicIt/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**v1_sessions_post**](UsersApi.md#v1_sessions_post) | **POST** /v1/sessions | 
[**v1_users_nick_followers_patch**](UsersApi.md#v1_users_nick_followers_patch) | **PATCH** /v1/users/{nick}/followers | 
[**v1_users_nick_get**](UsersApi.md#v1_users_nick_get) | **GET** /v1/users/{nick} | 

# **v1_sessions_post**
> v1_sessions_post(object=object, object=object, object=object)



Inicio de sesión

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.UsersApi()
object = 'object_example' # str | Nombre de usuario (optional)
object = 'object_example' # str | Email de usuario (optional)
object = 'object_example' # str | Passsword de usuario (optional)

try:
    api_instance.v1_sessions_post(object=object, object=object, object=object)
except ApiException as e:
    print("Exception when calling UsersApi->v1_sessions_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **object** | **str**| Nombre de usuario | [optional] 
 **object** | **str**| Email de usuario | [optional] 
 **object** | **str**| Passsword de usuario | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v1_users_nick_followers_patch**
> v1_users_nick_followers_patch(object=object)



Indica que sigues a X usuario

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.UsersApi()
object = true # bool | Boolean que indica si sigues o no al usuario (optional)

try:
    api_instance.v1_users_nick_followers_patch(object=object)
except ApiException as e:
    print("Exception when calling UsersApi->v1_users_nick_followers_patch: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **object** | **bool**| Boolean que indica si sigues o no al usuario | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v1_users_nick_get**
> v1_users_nick_get(name=name, object=object, object=object, object=object, object=object)



Obtener información de cualquier usuario

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.UsersApi()
name = 'name_example' # str | Buscar por nombre (optional)
object = 'object_example' # str | Buscar por username (optional)
object = 56 # int | Generar número de seguidores (optional)
object = 56 # int | Generar número de seguidos (optional)
object = 56 # int | Generar número total de likes (optional)

try:
    api_instance.v1_users_nick_get(name=name, object=object, object=object, object=object, object=object)
except ApiException as e:
    print("Exception when calling UsersApi->v1_users_nick_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **str**| Buscar por nombre | [optional] 
 **object** | **str**| Buscar por username | [optional] 
 **object** | **int**| Generar número de seguidores | [optional] 
 **object** | **int**| Generar número de seguidos | [optional] 
 **object** | **int**| Generar número total de likes | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

