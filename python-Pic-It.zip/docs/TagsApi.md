# swagger_client.TagsApi

All URIs are relative to *https://virtserver.swaggerhub.com/EPEREIROS_1/PicIt/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**v1_tagsquery_get**](TagsApi.md#v1_tagsquery_get) | **GET** /v1/tags?query&#x3D;{¿?} | 

# **v1_tagsquery_get**
> v1_tagsquery_get(object=object, object=object)



Obtener tags de la pantalla de subir post(autocompletado)

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.TagsApi()
object = 56 # int | Id del tag (optional)
object = 'object_example' # str | Etiqueta asociada a la publicación (optional)

try:
    api_instance.v1_tagsquery_get(object=object, object=object)
except ApiException as e:
    print("Exception when calling TagsApi->v1_tagsquery_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **object** | **int**| Id del tag | [optional] 
 **object** | **str**| Etiqueta asociada a la publicación | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

