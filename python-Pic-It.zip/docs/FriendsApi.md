# swagger_client.FriendsApi

All URIs are relative to *https://virtserver.swaggerhub.com/EPEREIROS_1/PicIt/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**v1_friends_get**](FriendsApi.md#v1_friends_get) | **GET** /v1/friends | 
[**v1_friends_id_message_post**](FriendsApi.md#v1_friends_id_message_post) | **POST** /v1/friends/{id}/message | 
[**v1_friends_id_messages_get**](FriendsApi.md#v1_friends_id_messages_get) | **GET** /v1/friends/{id}/messages | 

# **v1_friends_get**
> v1_friends_get(object=object, object=object)



Lista tus amigos para chatear

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FriendsApi()
object = 56 # int | Id del usuario amigo (optional)
object = 'object_example' # str | Username del usuario amigo (optional)

try:
    api_instance.v1_friends_get(object=object, object=object)
except ApiException as e:
    print("Exception when calling FriendsApi->v1_friends_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **object** | **int**| Id del usuario amigo | [optional] 
 **object** | **str**| Username del usuario amigo | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v1_friends_id_message_post**
> v1_friends_id_message_post(object=object)



envía un mensaje a un usuario amigo

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FriendsApi()
object = 'object_example' # str | Mensaje enviado por un usuario local a un usuario amigo (optional)

try:
    api_instance.v1_friends_id_message_post(object=object)
except ApiException as e:
    print("Exception when calling FriendsApi->v1_friends_id_message_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **object** | **str**| Mensaje enviado por un usuario local a un usuario amigo | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v1_friends_id_messages_get**
> v1_friends_id_messages_get(object=object, object=object, object=object, object=object, object=object, object=object)



Lista todos los mensajes del chat ordenados de antiguo a reciente (el primero el más reciente)

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FriendsApi()
object = 'object_example' # str | Nombre del usuario local (optional)
object = 'object_example' # str | Mensaje enviado por el usuario local (optional)
object = swagger_client.ModelDatetime() # ModelDatetime | Fecha y hora del mensaje enviado por el usuario local (optional)
object = 'object_example' # str | Nombre del usuario amigo que envía el mensaje (optional)
object = 'object_example' # str | Mensaje enviado por el usuario amigo (optional)
object = swagger_client.ModelDatetime() # ModelDatetime | Fecha y hora del mensaje enviado por el usuario amigo (optional)

try:
    api_instance.v1_friends_id_messages_get(object=object, object=object, object=object, object=object, object=object, object=object)
except ApiException as e:
    print("Exception when calling FriendsApi->v1_friends_id_messages_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **object** | **str**| Nombre del usuario local | [optional] 
 **object** | **str**| Mensaje enviado por el usuario local | [optional] 
 **object** | [**ModelDatetime**](.md)| Fecha y hora del mensaje enviado por el usuario local | [optional] 
 **object** | **str**| Nombre del usuario amigo que envía el mensaje | [optional] 
 **object** | **str**| Mensaje enviado por el usuario amigo | [optional] 
 **object** | [**ModelDatetime**](.md)| Fecha y hora del mensaje enviado por el usuario amigo | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

