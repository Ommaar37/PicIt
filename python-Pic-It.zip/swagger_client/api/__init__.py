from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from swagger_client.api.folders_api import FoldersApi
from swagger_client.api.friends_api import FriendsApi
from swagger_client.api.like_api import LikeApi
from swagger_client.api.posts_api import PostsApi
from swagger_client.api.tags_api import TagsApi
from swagger_client.api.users_api import UsersApi
